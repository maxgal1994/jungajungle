package com.example.jungajungle;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class myListViewAdapter extends ArrayAdapter<Item> {
    Context context;
    ArrayList<Item> objects;

    public myListViewAdapter(Context context, int resource, ArrayList<Item> objects){
        super(context, resource, objects);

        this.context = context;
        this.objects = objects;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View v = inflater.inflate(R.layout.row,null);

        TextView tvPrice = v.findViewById(R.id.tvPrice);
        TextView tvDesc = v.findViewById(R.id.tvDesc);
        TextView tvName = v.findViewById(R.id.tvName);
        ImageView imageView = v.findViewById(R.id.iv);

        tvPrice.setText(""+ (int) objects.get(position).realprice + "$");
        tvDesc.setText(objects.get(position).desc);
        tvName.setText(objects.get(position).name);
        //ImageView.setImageResources(R.drawable.slave); //objects.get(position).pic);

        Picasso.get().load(objects.get(position).pic).into(imageView);
        return v;
    }

}
