package com.example.jungajungle;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class myOrdersViewAdapter extends ArrayAdapter<Order> {
    Context context;
    ArrayList<Order> objects;

    public myOrdersViewAdapter(Context context, int resource, ArrayList<Order> objects){
        super(context, resource, objects);

        this.context = context;
        this.objects = objects;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View v = inflater.inflate(R.layout.roworder,null);

        TextView tvUsername = v.findViewById(R.id.tvUsername);
        TextView tvDate = v.findViewById(R.id.tvDate);
        TextView tvStatus = v.findViewById(R.id.tvStatus);
        TextView tvTotalCart = v.findViewById(R.id.tvTotalCart);
        TextView tvCart = v.findViewById(R.id.tvCart);

        tvUsername.setText("Username= "+objects.get(position).username);
        tvDate.setText("Date= "+objects.get(position).time+"");
        tvStatus.setText("Status= "+objects.get(position).status);
        tvTotalCart.setText("Total= "+objects.get(position).total + "$");
        tvCart.setText("Cart= "+objects.get(position).cart.toString());
        return v;
    }
}
