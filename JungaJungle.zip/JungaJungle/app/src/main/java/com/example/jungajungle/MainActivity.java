package com.example.jungajungle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * Login/Register Screen Activity
 */
public class MainActivity extends AppCompatActivity {
    Button btnLogin,btnGuest,btnRegister,btnAdmin;
    EditText etUsername,etPassword;
    ArrayList<User> users = new ArrayList<>();

    // Connect to the database
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://jungajungle-699a2-default-rtdb.firebaseio.com/");
    DatabaseReference myRef = database.getReference();

    /**
     * Create Activity
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin = findViewById(R.id.btnLogin);
        btnGuest = findViewById(R.id.btnGuest);
        btnRegister = findViewById(R.id.btnRegister);
        btnAdmin = findViewById(R.id.btnAdmin);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        Query q = myRef.child("Users");

    //testing firebase
//        myRef.child("stam").setValue("Hello, World!");
//
        //creating users local
//        for(int i=0;i<100;i++){
//            User u=new User("admin"+i,"admin");
//            users.add(u);
//        }
        //send array of users to firebase -one time only use
//        for(int i=0; i<users.size();i++){
//            myRef.child("Users").push().setValue(users.get(i));
//        }

        //singup and create users on firebase
        btnRegister.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                User u = new User(username, password);

                q.addListenerForSingleValueEvent(new ValueEventListener() {
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        boolean exists = false;

                        for (DataSnapshot dst : dataSnapshot.getChildren()) {

                            User u1 = dst.getValue(User.class);

                            if (u.username.equals(u1.username)) {
                                exists = true;
                            }
                        }
                        //end of loop

                        if (exists==true) {
                            Toast.makeText(MainActivity.this, "user with this name already exists", Toast.LENGTH_SHORT).show();
                        }
                        else if(u.username.equals("") || u.password.equals("")){
                            Toast.makeText(MainActivity.this, "Failed! Text field is empty!", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            myRef.child("Users").push().setValue(u);
                            Toast.makeText(MainActivity.this, "Registered Sucsessfully", Toast.LENGTH_SHORT).show();
                        }
                    }

                    public void onCancelled(DatabaseError error) {
                    }
                });
            }
        });
                //user clicks login
                btnLogin.setOnClickListener(new View.OnClickListener() {

                    public void onClick(View v) {
//                for(int i=0;i<users.size();i++){
//                    if(users.get(i).username.equals(etUsername.getText().toString()) && users.get(i).password.equals(etPassword.getText().toString())){
//                        Intent intent = new Intent(MainActivity.this,MainActivity2.class);
//                        intent.putExtra("user",users.get(i).username);
//                        startActivity(intent);
//                        Toast.makeText(MainActivity.this,"LOGGED SUCSSESFULLY!",Toast.LENGTH_LONG).show();
//                    }
//                }
                        String username = etUsername.getText().toString();
                        String password = etPassword.getText().toString();
                        User u = new User(username, password);

                        q.addListenerForSingleValueEvent(new ValueEventListener() {
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                boolean exists = false;
                                for (DataSnapshot dst : dataSnapshot.getChildren()) {
                                    User u1 = dst.getValue(User.class);
                                    if (u.username.equals(u1.username) && u.password.equals(u1.password)) {
                                        exists = true;
                                    }
                                }
                                //end of loop
                                if (exists==true) {
                                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                                    intent.putExtra("user", u.username);
                                    startActivity(intent);
                                    Toast.makeText(MainActivity.this, "LOGGED SUCSSESFULLY!", Toast.LENGTH_LONG).show();
                                }
                                else
                                    Toast.makeText(MainActivity.this, "LOGIN FAILED!", Toast.LENGTH_LONG).show();

                            }

                            public void onCancelled(DatabaseError error) {
                            }
                        });
                    }
                });
                //user clicks guest
                btnGuest.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                        intent.putExtra("user", "Guest");
                        startActivity(intent);
                        Toast.makeText(MainActivity.this, "LOGGED SUCSSESFULLY!", Toast.LENGTH_SHORT).show();
                    }
                });

                //user is admin and clicks admin (username=max pass=max)
                btnAdmin.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        String username = etUsername.getText().toString();
                        String password = etPassword.getText().toString();
                        if(username.equals("max") && password.equals("max")){
                            Intent intent = new Intent(MainActivity.this, MainActivity4.class);
                            intent.putExtra("user", username+"");
                            startActivity(intent);
                            Toast.makeText(MainActivity.this, "Welcome Back "+username+"!", Toast.LENGTH_SHORT).show();
                        }
                        else
                            Toast.makeText(MainActivity.this, "Try again!"+username, Toast.LENGTH_SHORT).show();


                    }
                });
            }
    }

