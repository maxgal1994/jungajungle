package com.example.jungajungle;

public class Item {
    public String name,desc,pic,price;
    public double realprice;

    Item(String name,String desc,String pic,double realprice){
        this.name=name;
        this.desc=desc;
        this.pic=pic;
        this.realprice=realprice;
    }
    Item(){}

}
