package com.example.jungajungle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class MainActivity3 extends AppCompatActivity {
    Button btnReturn,btnPurchase;
    TextView tvTotal;

    // Connect to the database
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://jungajungle-699a2-default-rtdb.firebaseio.com/");
    DatabaseReference myRef = database.getReference();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        tvTotal = findViewById(R.id.tvTotal);
        btnReturn = findViewById(R.id.btnReturn);
        btnPurchase = findViewById(R.id.btnPurchase);
        setTitle("Checkout");

        if(getIntent().hasExtra("total"))
            tvTotal.setText(getIntent().getStringExtra("total"));

        btnPurchase.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                Order order = new Order();
                if(getIntent().hasExtra("total"))
                    order.total=(getIntent().getStringExtra("total"));
                if(getIntent().hasExtra("user"))
                    order.username=(getIntent().getStringExtra("user"));
                order.cart=MainActivity2.Cart;
                order.status="Processing";
                order.time= Calendar.getInstance().getTime();

                myRef.child("Orders").push().setValue(order);

                Toast.makeText(MainActivity3.this,"Thanks for purchasing",Toast.LENGTH_SHORT).show();
                finishAffinity();
            }
        });
        btnReturn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
    }
}