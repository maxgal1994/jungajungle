package com.example.jungajungle;

public class User {
    public String username,password;

    User(String username,String password){
        this.username=username;
        this.password=password;
    }
    User(){}

}
