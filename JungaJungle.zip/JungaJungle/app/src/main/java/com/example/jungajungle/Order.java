package com.example.jungajungle;

import java.util.ArrayList;
import java.util.Date;

public class Order {
    public String username,status,total;
    public Date time;
    public ArrayList<Item> cart;

    public Order(String username,String status,String total,Date time,ArrayList<Item> cart){
        this.username=username;
        this.status=status;
        this.total=total;
        this.time=time;
        this.cart=cart;
    }
    public Order(){}

    @Override
    public String toString() {
        return "Order{" +
                "username='" + username + '\'' +
                ", status='" + status + '\'' +
                ", total='" + total + '\'' +
                ", time=" + time +
                ", cart=" + cart +
                '}';
    }
}
