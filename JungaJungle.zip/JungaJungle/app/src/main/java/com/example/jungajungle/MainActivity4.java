package com.example.jungajungle;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity4 extends AppCompatActivity {
    //button for opening dialog to add product
    Button btnAddProduct;
    //list view to show products and orders from firebase
    ListView lvOrders,lvProducts;
    //arrays will get orders and products from firebase;
    ArrayList<Order> orders = new ArrayList<>();
    ArrayList<Item> products = new ArrayList<>();

    //dialog values
    Button btnAddItem,btnDismissDialog;
    EditText etItemName,etItemDesc,etImageURL,etPrice;

    // Connect to the database
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://jungajungle-699a2-default-rtdb.firebaseio.com/");
    DatabaseReference myRef = database.getReference();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        btnAddProduct = findViewById(R.id.btnAddProduct);
        lvOrders = findViewById(R.id.lvOrders);
        lvProducts = findViewById(R.id.lvProducts);

        //set title with user's name
        if(getIntent().hasExtra("user")){
            setTitle("Hello "+(getIntent().getStringExtra("user")));
        }
        //read orders from firebase to array list
        Query q = myRef.child("Orders");
        q.addListenerForSingleValueEvent(new ValueEventListener() {
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot dst : dataSnapshot.getChildren()) {
                    Order o = dst.getValue(Order.class);
                    orders.add(o);
                }
            }
            public void onCancelled(DatabaseError error) {
            }
        });
        //read products from fire base to array list
        q = myRef.child("items");
        q.addListenerForSingleValueEvent(new ValueEventListener() {
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot dst : dataSnapshot.getChildren()) {
                    Item i = dst.getValue(Item.class);
                    products.add(i);
                    //refresh list view of orders+products array
                    refresh_lv();
                }
            }
            public void onCancelled(DatabaseError error) {
            }
        });

        btnAddProduct.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                //----------------enter dialog-------------------------------------------------
                        Dialog dialog = new Dialog(MainActivity4.this);
                        dialog.setContentView(R.layout.mydialog2);
                        btnAddItem = dialog.findViewById(R.id.btnAddItem);
                        btnDismissDialog = dialog.findViewById(R.id.btnDismissDialog);
                        etItemName = dialog.findViewById(R.id.etItemName);
                        etItemDesc = dialog.findViewById(R.id.etItemDesc);
                        etImageURL = dialog.findViewById(R.id.etImageURL);
                        etPrice = dialog.findViewById(R.id.etPrice);

                        //add product to firebase and dismiss dialog
                        btnAddItem.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                Item newItem = new Item();
                                newItem.name=etItemName.getText().toString();
                                newItem.desc=etItemDesc.getText().toString();
                                newItem.realprice=Double.parseDouble(String.valueOf(etPrice.getText().toString()));
                                if(etImageURL.getText().toString().equals("Image Url"))
                                    newItem.pic="https://bestgraphics.net/wp-content/uploads/2015/06/Coming-Soon.jpg";
                                else
                                    newItem.pic=etImageURL.getText().toString();
                                products.add(newItem);
                                myRef.child("items").push().setValue(newItem);
                                refresh_lv();
                                dialog.dismiss();
                            }
                        });
                        //dismiss dialog
                        btnDismissDialog.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });
                        //open dialog
                        dialog.show();
                    }
                });

    }
//refresh list views of orders+products
    public void refresh_lv() {
        //products arraylist adapter
        myListViewAdapter adp = new myListViewAdapter(this,R.layout.row,products);
        lvProducts.setAdapter(adp);
        //orders arraylist adapter
        myOrdersViewAdapter adp2 = new myOrdersViewAdapter(this,R.layout.roworder,orders);
        lvOrders.setAdapter(adp2);
    }
}