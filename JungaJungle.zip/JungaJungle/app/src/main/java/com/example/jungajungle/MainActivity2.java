package com.example.jungajungle;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * Main Screen that contains shop list of items and option to add to cart with dialog and go to checkout screen
 */
public class MainActivity2 extends AppCompatActivity {
    ListView lvProducts;
    Button btnCheckout,btnAdd,btnDismiss;
    EditText etTotal;
    TextView tvShowPrice;
    //old array containing products that have been sent to fire base;
    //ArrayList<Item> array = new ArrayList<>();
    //new array that reads products from fire base
    public static ArrayList<Item> Products = new ArrayList<>();
    public static ArrayList<Item> Cart = new ArrayList<>();
    String username;

    // Connect to the database
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://jungajungle-699a2-default-rtdb.firebaseio.com/");
    DatabaseReference myRef = database.getReference();

    /**
     * Activity Creation Starts Here
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        lvProducts = findViewById(R.id.lvProducts);
        btnCheckout = findViewById(R.id.btnCheckout);
        etTotal = findViewById(R.id.etTotal);

        //set title with user's name
        if(getIntent().hasExtra("user")){
            setTitle("Hello "+(getIntent().getStringExtra("user")));
            username= getIntent().getStringExtra("user");
        }


//        Item bowl = new Item("bowl of good","pretty good bowl for doggo catz","https://cdn.shopify.com/s/files/1/0567/8691/1409/products/19628417986_6_1024x1024@2x.jpg?v=1621318822",100);
//        array.add(bowl);
//        Item toi = new Item("toi of good","pretty toi good for doggo catz","https://cdn.shopify.com/s/files/1/0567/8691/1409/products/b1f99697-a463-4335-abf0-03253e7e8604_3_540x.jpg?v=1638476681",250);
//        array.add(toi);
//        Item Costume = new Item("Chucky Costume","Funny Costume for your little furry puppy, will make the atmosphere much more funnier","https://cdn.shopify.com/s/files/1/0567/8691/1409/products/49739969990459_3_1024x1024@2x.jpg?v=1632481443",110);
//        array.add(Costume);
//        Item Hat = new Item("Rendeer Hat","A Rendeer lookalike hat to celebrate christmas with your pet","https://cdn.shopify.com/s/files/1/0567/8691/1409/products/248414926380_3_540x.jpg?v=1638734794",56);
//        array.add(Hat);

        //send array of items to firebase -one time only use
//        for(int i=0; i<array.size();i++){
//            myRef.child("items").push().setValue(array.get(i));
//        }

        //read products from firebase and palce them to array
        Query q = myRef.child("items");
        q.addListenerForSingleValueEvent(new ValueEventListener() {
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot dst : dataSnapshot.getChildren()) {
                    Item product = dst.getValue(Item.class);
                    Products.add(product);
                }
                refresh_lv();
            }
            public void onCancelled(DatabaseError error) {
            }
        });


        //----------------enter dialog-------------------------------------------------
        lvProducts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Dialog dialog = new Dialog(MainActivity2.this);
                dialog.setContentView(R.layout.mydialog);
                btnAdd = dialog.findViewById(R.id.btnAdd);
                btnDismiss = dialog.findViewById(R.id.btnDismiss);
                tvShowPrice = dialog.findViewById(R.id.tvShowPrice);
                //set product's price
                tvShowPrice.setText(Products.get(position).price);
                //add price to total and dismiss dialog
                btnAdd.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        String getEt = etTotal.getText().toString();
                        double d = Double.parseDouble(getEt);
                        double d2 = d + Products.get(position).realprice;

                        etTotal.setText(""+d2);
                        Cart.add(Products.get(position));
                        dialog.dismiss();
                    }
                });
                //dismiss dialog
                btnDismiss.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                //open dialog
                dialog.show();
            }
        });

        btnCheckout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this,MainActivity3.class);
                intent.putExtra("total",etTotal.getText().toString());
                intent.putExtra("user",username);
                startActivity(intent);
            }
        });

    }

    /**
     * Function that refreshes list view with adapter
     * @lvProducts is a listview that will contain the products from arraylist
     */
        public void refresh_lv() {
            myListViewAdapter adp = new myListViewAdapter(this,R.layout.row,Products);
            lvProducts.setAdapter(adp);
        }
}